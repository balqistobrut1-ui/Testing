package com.tj.legobatman;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import java.util.List;
import org.libsdl.app.SDLActivity;

public class LegoBatmanActivity extends SDLActivity {
    /* true while the game runs; the launcher then only offers Resume */
    static volatile boolean sRunning;

    private static native void nativeSetTouchUi(float scale, int opacity);
    private static native float nativeGetTouchScale();
    private static native int nativeGetTouchOpacity();
    private static native void nativeSetTouchLayoutEdit(int enabled);
    private static native void nativeResetTouchLayout();

    /* Compact in-game touch-control panel, anchored at the top centre. */
    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void addTouchSettingsOverlay() {
        if (mLayout == null) return;
        final LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(Gravity.CENTER_HORIZONTAL);

        Button toggle = new Button(this);
        toggle.setText("⚙  TOUCH SETTINGS");
        toggle.setTextSize(11);
        toggle.setAllCaps(false);
        toggle.setPadding(dp(12), 0, dp(12), 0);
        wrapper.addView(toggle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)));

        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(8), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE820222A);
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), 0xFF777D8A);
        panel.setBackground(bg);
        panel.setVisibility(View.GONE);
        wrapper.addView(panel, new LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView heading = new TextView(this);
        heading.setText("PENGATURAN KONTROL");
        heading.setTextColor(Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextSize(12);
        panel.addView(heading);

        TextView sizeLabel = new TextView(this);
        sizeLabel.setText("Ukuran tombol: 100%");
        sizeLabel.setTextColor(0xFFEAEAEA);
        panel.addView(sizeLabel);
        SeekBar size = new SeekBar(this);
        size.setMax(85);
        size.setProgress(35); // 0.65x .. 1.50x, default 1.00x
        panel.addView(size);

        TextView opacityLabel = new TextView(this);
        opacityLabel.setText("Opasitas: 58%");
        opacityLabel.setTextColor(0xFFEAEAEA);
        panel.addView(opacityLabel);
        SeekBar opacity = new SeekBar(this);
        opacity.setMax(85);
        opacity.setProgress(43); // 15 .. 100, default 58
        panel.addView(opacity);

        Button editLayout = new Button(this);
        editLayout.setText("ATUR POSISI TOMBOL");
        editLayout.setTextSize(10);
        editLayout.setAllCaps(false);
        panel.addView(editLayout, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        Button resetLayout = new Button(this);
        resetLayout.setText("RESET POSISI DEFAULT");
        resetLayout.setTextSize(10);
        resetLayout.setAllCaps(false);
        panel.addView(resetLayout, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        resetLayout.setOnClickListener(v -> nativeResetTouchLayout());

        TextView hint = new TextView(this);
        hint.setText("Aktifkan mode posisi, lalu seret tombol/analog. Perubahan tersimpan otomatis.");
        hint.setTextColor(0xFFB8C0CC);
        hint.setTextSize(10);
        panel.addView(hint);
        final boolean[] editing = { false };
        editLayout.setOnClickListener(v -> {
            editing[0] = !editing[0];
            nativeSetTouchLayoutEdit(editing[0] ? 1 : 0);
            editLayout.setText(editing[0] ? "SELESAI ATUR POSISI" : "ATUR POSISI TOMBOL");
            hint.setText(editing[0] ? "Seret tombol atau analog ke posisi yang diinginkan." : "Posisi kontrol tersimpan otomatis.");
        });

        final Runnable apply = () -> {
            float scale = 0.65f + size.getProgress() / 100.0f;
            int alpha = 15 + opacity.getProgress();
            sizeLabel.setText("Ukuran tombol: " + Math.round(scale * 100) + "%");
            opacityLabel.setText("Opasitas: " + alpha + "%");
            nativeSetTouchUi(scale, alpha);
        };
        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { apply.run(); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { apply.run(); }
            public void onStartTrackingTouch(SeekBar b) { }
            public void onStopTrackingTouch(SeekBar b) { }
        });
        toggle.setOnClickListener(v -> {
            if (panel.getVisibility() == View.VISIBLE) {
                panel.setVisibility(View.GONE);
            } else {
                float currentScale = nativeGetTouchScale();
                int currentOpacity = nativeGetTouchOpacity();
                size.setProgress(Math.max(0, Math.min(85, Math.round((currentScale - 0.65f) * 100))));
                opacity.setProgress(Math.max(0, Math.min(85, currentOpacity - 15)));
                sizeLabel.setText("Ukuran tombol: " + Math.round(currentScale * 100) + "%");
                opacityLabel.setText("Opasitas: " + currentOpacity + "%");
                panel.setVisibility(View.VISIBLE);
            }
        });

        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        lp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        lp.topMargin = dp(6);
        mLayout.addView(wrapper, lp);
        wrapper.bringToFront();
    }

    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL2", "dxvk_d3d9", "main" };
    }

    /* argv[1] = game folder, argv[2] = save folder, from the launcher. */
    @Override
    protected String[] getArguments() {
        String game = getIntent().getStringExtra("game"), save = getIntent().getStringExtra("save");
        if (game == null) return new String[0];
        return save == null ? new String[] { game } : new String[] { game, save };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        saveLastExit();
        super.onCreate(savedInstanceState);
        sRunning = true;
        addTouchSettingsOverlay();
    }

    @Override
    protected void onDestroy() {
        sRunning = false;
        super.onDestroy();
    }

    /* Back opens the launcher over the game (SDL pauses it meanwhile). */
    @Override
    public void onBackPressed() {
        Intent i = new Intent(this, LauncherActivity.class);
        i.putExtra("ingame", true);
        startActivity(i);
    }

    /* Why the previous run ended (crash, low memory kill, ...), kept in
     * <game>/port/last_exit.txt since log.txt is replaced on every launch. */
    private void saveLastExit() {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(null, 0, 3);
            String game = getIntent().getStringExtra("game");
            File dir = game != null ? new File(game, "port") : null;
            if (dir != null) dir.mkdirs();
            if (l.isEmpty() || dir == null) return;
            try (FileWriter w = new FileWriter(new File(dir, "last_exit.txt"))) {
                for (ApplicationExitInfo e : l) {
                    w.write(new Date(e.getTimestamp()) + ": reason " + reasonName(e.getReason())
                            + " status " + e.getStatus() + " importance " + e.getImportance()
                            + " pss " + e.getPss() / 1024 + "MB rss " + e.getRss() / 1024 + "MB"
                            + " desc " + e.getDescription() + "\n");
                }
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                w.write("device RAM " + mi.totalMem / (1 << 20) + "MB, available now " + mi.availMem / (1 << 20)
                        + "MB, low-memory threshold " + mi.threshold / (1 << 20) + "MB, "
                        + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + "\n");
            }
        } catch (Exception ignored) {
        }
    }

    private static String reasonName(int r) {
        switch (r) {
        case ApplicationExitInfo.REASON_LOW_MEMORY: return "LOW_MEMORY";
        case ApplicationExitInfo.REASON_CRASH: return "CRASH_JAVA";
        case ApplicationExitInfo.REASON_CRASH_NATIVE: return "CRASH_NATIVE";
        case ApplicationExitInfo.REASON_SIGNALED: return "SIGNALED";
        case ApplicationExitInfo.REASON_ANR: return "ANR";
        case ApplicationExitInfo.REASON_EXIT_SELF: return "EXIT_SELF";
        case ApplicationExitInfo.REASON_USER_REQUESTED: return "USER_REQUESTED";
        case ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE: return "EXCESSIVE_RESOURCE_USAGE";
        case ApplicationExitInfo.REASON_OTHER: return "OTHER";
        default: return "code " + r;
        }
    }
}
